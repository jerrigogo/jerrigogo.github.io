let menuList = [
  { name: 'Menu1', path: '/' },
  { name: 'Menu2', path: '/' },
];

let _ui = {
  init: (_idx) => {
    // pc/mobile check
    // _ui.chkDevice();

    // layout
    // _ui.layout.header();
    // _ui.layout.drawerMenu(_idx);
    // _ui.layout.footer();
    _ui.layout.modalReady();

    // components
    _ui.tabContents();
    _ui.accordions.init();
  },
  chkDevice: () => {
    let html = document.querySelector('html');
    let mobile = 414;
    let tablet = 1024;
    let device, osType, browserType;

    html.removeAttribute('class');

    const chkWinSize = () => {
      let winW = window.innerWidth;

      if (winW <= mobile) {
        device = 'mobile';
      } else if (winW > mobile && winW <= tablet) {
        device = 'tablet';
      } else {
        device = 'pc';
      }

      html.setAttribute('class', device);
    };

    const getDevicetype = () => {
      let userAgent = navigator.userAgent;
      let isIOS = /iPhone|iPod/.test(userAgent);
      let isIpad = /Macintosh|iPad/.test(userAgent);
      let isAnd = /android/i.test(userAgent);

      if (isIOS) {
        osType = 'iOS';

        if (/CriOS/.test(userAgent)) {
          browserType = 'Chrome';
        } else if (/Safari/.test(userAgent) && !/CriOS/.test(userAgent)) {
          browserType = 'Safari';
        } else if (/KAKAOTALK/.test(userAgent)) {
          browserType = 'Kakao';
        } else {
          browserType = '';
        }
      } else if (isIpad) {
        if (navigator.maxTouchPoints > 0) {
          osType = 'iPad';

          if (/CriOS/.test(userAgent)) {
            browserType = 'Chrome';
          } else if (/Safari/.test(userAgent) && !/CriOS/.test(userAgent)) {
            browserType = 'Safari';
          } else if (/KAKAOTALK/.test(userAgent)) {
            browserType = 'Kakao';
          } else {
            browserType = '';
          }
        }
      } else if (isAnd) {
        osType = 'Android';

        if (/Chrome/.test(userAgent)) {
          browserType = 'Chrome';
        } else if (/SamsungBrowser/.test(userAgent)) {
          browserType = 'SamsungBrowser';
        } else if (/KAKAOTALK/.test(userAgent)) {
          browserType = 'Kakao';
        } else {
          browserType = '';
        }
      } else {
        osType = '';
        browserType = '';
      }

      if (osType) html.dataset.device = osType;
      if (browserType) html.dataset.browser = browserType;
    };

    chkWinSize();
    getDevicetype();

    window.addEventListener('resize', chkWinSize);
  },
  layout: {
    header: () => {
      let main = document.querySelector('#MainContainer');
      let headerWrap = document.createElement('header');

      headerWrap.setAttribute('id', 'HeaderContainer');
      headerWrap.setAttribute('class', 'header-container');
      main.before(headerWrap);

      let header = '<div class="header-wrap">';
      header += '<h1 class="header-title">Logo</h1>';
      header += '</div>';

      headerWrap.innerHTML = header;
    },
    drawerMenu: (_idx) => {
      let main = document.querySelector('#MainContainer');
      let naviWrap = document.createElement('aside');

      naviWrap.setAttribute('id', 'AsideContainer');
      naviWrap.setAttribute('class', 'aside-container');
      main.before(naviWrap);

      let drawer = '<nav id="NaviContainer" class="navi-container">';
      drawer += '<div class="drawer-header">';
      drawer += '<button type="button" class="drawer-close" onclick="toggleAside(this)"><span class="bar"></span><span class="sr-only">메뉴 닫기</span></button>';
      drawer += '</div>';
      drawer += '<div class="navi-list">';
      drawer += '<ul>';

      menuList.forEach((menu, index) => {
        let selClass = index == _idx ? 'sel' : '';

        drawer += '<li>';
        drawer += '<button class="menu-link ' + selClass + '" onclick="javascript:movePage(`' + menu.path + '`);"><span>' + menu.name + '</span></button>';
        drawer += '</li>';
      });

      drawer += '</ul>';
      drawer += '</div>';
      drawer += '</nav>';

      naviWrap.innerHTML = drawer;
    },
    footer: () => {
      let main = document.querySelector('#MainContainer');
      let footerWrap = document.createElement('footer');

      footerWrap.setAttribute('id', 'FooterContainer');
      footerWrap.setAttribute('class', 'footer-container');
      main.after(footerWrap);

      let footer = '<div class="footer-wrap">';
      footer += '</div>';

      footerWrap.innerHTML = footer;
    },
    modalReady: () => {
      let body = document.querySelector('body');
      let modalLayout = document.querySelector('.modal-layout');
      let modals = modalLayout && modalLayout.querySelectorAll('.modal-wrap');
      let cLayout = document.createElement('div');
      let cDim = document.createElement('div');

      cDim.setAttribute('class', 'modal-dim');

      if (modalLayout) {
        modalLayout.prepend(cDim);
      } else {
        cLayout.setAttribute('class', 'modal-layout');
        cLayout.prepend(cDim);
        body.append(cLayout);
      }

      // modal의 a11y 설정
      if (modals) {
        modals.forEach((modal) => {
          let modalId = modal.getAttribute('id');
          let modalHeader = modal.querySelector('.modal-header');

          modal.setAttribute('role', 'dialog');
          modal.setAttribute('aria-modal', true);
          modal.setAttribute('aria-labelledby', `${modalId}-title`);
          modal.setAttribute('tabindex', -1);
          modalHeader.setAttribute('id', `${modalId}-title`);
        });
      }
    },
  },
  modal: {
    data: {
      prevFocus: [],
      prevModals: [],
    },
    open: (_id, _target) => {
      let modalLayout = document.querySelector('.modal-layout');
      let modalWrap = document.querySelector(`#${_id}`);
      let zIndex = Number(getComputedStyle(modalLayout.querySelector('.modal-dim')).getPropertyValue('z-index'));
      let prevArray = _ui.modal.data.prevModals;
      let modalObj = {};

      // modal의 속성 설정 및 open
      modalWrap.style.zIndex = zIndex + prevArray.length + 1;
      modalWrap.classList.add('open');
      _target && _target.setAttribute('aria-expanded', true);

      // modal에 focus 가두기 실행 및 modal로 focus 이동
      // setTimeout 300 : modal의 css에 transition-duration 시간이 0.3s
      let timer = setTimeout(() => {
        modalWrap.focus();
        clearTimeout(timer);
      }, 300);

      // modal 내 focus trap 적용
      modalFocusTrap(_id);

      // open된 modal을 prevArray(임시 저장소)에 저장
      modalObj.id = _id;
      modalObj.zIndex = zIndex + prevArray.length + 1;
      prevArray.push(modalObj);

      // 자신을 제외한 open 상태인 modal이 없을 때
      if (prevArray.length - 1 < 1) {
        modalLayout.classList.add('open');
      }
      // 자신을 제외한 open 상태인 modal이 있을 때
      else {
        // open 상태인 modal의 z-index값 변경 - dim 뒤로
        prevArray.forEach((prev) => {
          let modalId = prev.id;
          let modalIndex = prev.zIndex - 10;
          let modal = document.querySelector(`#${modalId}`);

          if (modalId !== _id) {
            modal.style.zIndex = modalIndex;
          }
        });
      }

      // modal 띄운 요소 저장
      _target && _ui.modal.data.prevFocus.push(_target);

      // prevArray에 저장된 값을 _ui.modal.data.prevModals로 저장
      _ui.modal.data.prevModals = prevArray;

      // esc key close
      const escKeyClose = (e) => {
        let thisModal = document.querySelector(`#${_id}`);
        if (e.key == 'Escape') {
          e.preventDefault();
          _ui.modal.close(thisModal);

          modalWrap.removeEventListener('keydown', escKeyClose);
        }
      };

      modalWrap.addEventListener('keydown', escKeyClose);
    },
    close: (e) => {
      let modalLayout = document.querySelector('.modal-layout');
      let modalWrap = typeof e == 'object' ? e.closest('.modal-wrap') : modalLayout.querySelector(`#${e}`);
      let modals = modalLayout.querySelectorAll('.modal-wrap');
      let modalId = modalWrap.getAttribute('id');
      let reduceArray = _ui.modal.data.prevModals.filter((x) => x.id !== modalId);

      // modal close
      modalWrap.classList.remove('open');

      // 자신을 제외한 open 상태인 modal이 없을 때
      if (reduceArray.length < 1) {
        modalLayout.classList.remove('open');
        modalLayout.classList.add('close');

        // setTimeout 300 : modal의 css에 transition-duration 시간이 0.3s
        let timer = setTimeout(() => {
          modalLayout.classList.remove('close');
          if (_ui.modal.data.prevFocus[0]) {
            _ui.modal.data.prevFocus[0].focus();
            _ui.modal.data.prevFocus[0].setAttribute('aria-expanded', false);
            // 자신을 열었던 요소 삭제
            _ui.modal.data.prevFocus.pop();
          }
          clearTimeout(timer);
        }, 300);

        // 모든 modal의 style 삭제
        modals.forEach((modal) => {
          modal.removeAttribute('style');
        });
      }
      // 자신을 제외한 open 상태인 modal이 있을 때
      else {
        // 가장 늦게 open된 modal의 z-index값 원복 - dim 보다 위로
        let lastObj = reduceArray[reduceArray.length - 1];
        let lastId = lastObj.id;
        let lastIndex = lastObj.zIndex;
        let lastModal = document.querySelector(`#${lastId}`);
        lastModal.style.zIndex = lastIndex;

        // 자신을 열었던 요소로 focus 이동
        _ui.modal.data.prevFocus[_ui.modal.data.prevFocus.length - 1].focus();
        _ui.modal.data.prevFocus[_ui.modal.data.prevFocus.length - 1].setAttribute('aria-expanded', false);
        // 자신을 열었던 요소 삭제
        _ui.modal.data.prevFocus.pop();
      }

      _ui.modal.data.prevModals = reduceArray;

      modalWrap.removeEventListener('keydown', _ui.modal.escKeyClose);
    },
  },
  system: {
    data: {
      prevFocus: '',
      prevModals: [],
    },
    open: (_opt, _target) => {
      let id = _opt.id;
      let type = _opt.type ? _opt.type : 'alert';
      let title = _opt.title ? _opt.title : '안내';
      let cont = _opt.cont;
      let okText = _opt.okText ? _opt.okText : '확인';
      let cancelText = _opt.cancelText ? _opt.cancelText : '취소';
      let okCallback = _opt.okCallback;
      let cancelCallback = _opt.cancelCallback;
      let modalLayout = document.querySelector('.modal-layout');
      let modalOpens = document.querySelectorAll('.modal-wrap.open:not(.system)');
      let prevSysModal = document.querySelectorAll('.modal-wrap.system');
      let sysModal = document.createElement('div');
      let sysIndex = 1000 + modalOpens.length;
      let modalObj = `
        <div id="${id}-title" class="modal-header">
          <h1 class="modal-title">${title}</h1>
        </div>
        <div class="modal-body">
          <div class="modal-body-inner">${cont}</div>
        </div>
        <div class="modal-footer">
      `;

      // modal 띄운 요소 저장(기존 system modal이 없을 경우에만 저장)
      if (prevSysModal.length < 1) {
        _ui.system.data.prevFocus = _target;
      }

      _target && _target.setAttribute('aria-expanded', true);

      if (type == 'confirm') {
        modalObj += `
          <button type="button" class="modal-btn-cancel">
            <span>${cancelText}</span>
          </button>
        `;
      }

      modalObj += `
          <button type="button" class="modal-btn-ok">
            <span>${okText}</span>
          </button>
        </div>
        <button type="button" class="modal-close">
          <span class="sr-only">닫기</span>
        </button>
      `;

      sysModal.setAttribute('id', id);
      sysModal.setAttribute('class', 'modal-wrap system open');
      sysModal.setAttribute('role', 'alertdialog');
      sysModal.setAttribute('aria-modal', true);
      sysModal.setAttribute('aria-labelledby', `${id}-title`);
      sysModal.setAttribute('tabindex', -1);
      sysModal.style.zIndex = sysIndex;
      sysModal.innerHTML = modalObj;

      if (!modalLayout) {
        let body = document.querySelector('body');
        let cLayout = document.createElement('div');
        let cDim = document.createElement('div');

        cLayout.setAttribute('class', 'modal-layout open');
        cDim.setAttribute('class', 'modal-dim');

        body.append(cLayout);
        cLayout.append(cDim);
        cLayout.append(sysModal);
      } else {
        if (!modalLayout.classList.contains('open')) {
          modalLayout.classList.add('open');
        } else {
          // open 상태인 일반 modal의 z-index값 저장 후 dim의 z-index 보다 낮게 설정
          modalOpens.forEach((modalOpen) => {
            let moIndex = Number(getComputedStyle(modalOpen).getPropertyValue('z-index'));
            let moId = modalOpen.getAttribute('id');
            let zIndexObj = {};

            modalOpen.style.zIndex = moIndex - 10;

            // open 상태인 일반 modal의 id와 z-index 저장
            zIndexObj.id = moId;
            zIndexObj.zIndex = moIndex;
            _ui.system.data.prevModals.push(zIndexObj);
          });
        }

        modalLayout.append(sysModal);
      }

      // modal이 열렸을 때 focus 이동
      let timer = setTimeout(() => {
        sysModal.focus();
        clearTimeout(timer);
      }, 300);

      // modal 내 focus trap 적용
      modalFocusTrap(id);

      let thisModal = document.querySelector(`#${id}`);
      let okBtn = thisModal.querySelector('.modal-btn-ok');
      let cancelBtn = type == 'confirm' ? thisModal.querySelector('.modal-btn-cancel') : null;
      let closeBtn = thisModal.querySelector('.modal-close');

      // modal ok
      okBtn.addEventListener('click', (e) => {
        okCallback && okCallback();
        _ui.system.close(e);
      });

      // modal cancel
      if (type == 'confirm') {
        cancelBtn.addEventListener('click', (e) => {
          cancelCallback && cancelCallback();
          _ui.system.close(e);
        });
      }

      // modal close
      closeBtn.addEventListener('click', (e) => {
        _ui.system.close(e);
      });

      // esc key
      sysModal.addEventListener('keydown', (e) => {
        if (e.key == 'Escape') {
          e.preventDefault();
          _ui.system.close();
        }
      });
    },
    close: (e) => {
      let thisModal = !!e ? e.target.closest('.modal-wrap') : document.querySelector('.modal-wrap.system.open');
      let modalLayout = document.querySelector('.modal-layout');
      let sysModals = document.querySelectorAll('.modal-wrap.system');
      let nModals = document.querySelectorAll('.modal-wrap:not(.system)');
      let nModalOpens = document.querySelectorAll('.modal-wrap.open:not(.system)');

      // system modal remove
      thisModal.classList.remove('open');
      thisModal.classList.add('close');

      let thisTimer = setTimeout(() => {
        thisModal.remove();
        clearTimeout(thisTimer);
      }, 300);

      // 일반 modal 여부에 따른 조건
      // 일반 modal이 없을 때
      if (nModals.length < 1) {
        // 이미 open인 system modal이 없을 때: '닫기' 클릭 시 자기를 포함한 system modal 개수 확인
        if (sysModals.length < 2) {
          modalLayout.classList.remove('open');
          modalLayout.classList.add('close');

          let dimTimer = setTimeout(() => {
            modalLayout.classList.remove('close');
            modalLayout.remove();
            clearTimeout(dimTimer);
          }, 300);
        }
      }
      // 일반 modal이 있을 때
      else {
        // open 상태인 일반 modal이 없을 때
        if (nModalOpens.length < 1) {
          // 이미 open인 system modal이 없을 때: '닫기' 클릭 시 자기를 포함한 system modal 개수 확인
          if (sysModals.length < 2) {
            modalLayout.classList.remove('open');
            modalLayout.classList.add('close');

            let dimTimer = setTimeout(() => {
              modalLayout.classList.remove('close');
              clearTimeout(dimTimer);
            }, 300);
          }
        }
        // open 상태인 일반 modal이 있을 때
        else {
          // 이미 open인 system modal이 없을 때: '닫기' 클릭 시 자기를 포함한 system modal 개수 확인
          if (sysModals.length < 2) {
            // 저장했던 z-index를 일반 modal에 다시 부여
            nModalOpens.forEach((nModal) => {
              let modalId = nModal.getAttribute('id');
              let zIndexObj = _ui.system.data.prevModals.find((x) => x.id == modalId);
              nModal.style.zIndex = zIndexObj.zIndex;
            });

            let timer = setTimeout(() => {
              _ui.system.data.prevModals = [];
              clearTimeout(timer);
            }, 300);
          }
        }
      }

      // console.log(_ui.system.data.prevFocus);
      // if (sysModals.length > 1) {
      //   console.log(_ui.system.data.prevFocus);
      // }

      _ui.system.data.prevFocus && _ui.system.data.prevFocus.focus();
      _ui.system.data.prevFocus && _ui.system.data.prevFocus.setAttribute('aria-expanded', false);
    },
  },
  tabContents: () => {
    let tabWraps = document.querySelectorAll('.tabs-wrap');

    if (tabWraps.length < 1) return false;

    tabWraps.forEach((tabWrap) => {
      let tabList = tabWrap.children[0];
      let tabCont = tabWrap.children[1];
      let tabItems = tabList.querySelectorAll('.tab-item');
      let tabPanels = tabCont.children;

      tabList.setAttribute('role', 'tablist');

      // 초기화화
      const init = () => {
        tabItems.forEach((tabItem, index) => {
          tabItem.setAttribute('aria-selected', false);
          tabItem.setAttribute('aria-current', false);
          tabItem.setAttribute('tabindex', -1);
          tabPanels[index].setAttribute('aria-hidden', true);
        });
      };

      // a11y 적용
      tabItems.forEach((tabItem, index) => {
        let tabId = tabItem.getAttribute('id');
        let tabLabel = tabItem.innerText;
        let tabPanel = tabPanels[index];

        tabItem.setAttribute('role', 'tab');
        tabItem.setAttribute('title', tabLabel);
        tabItem.setAttribute('aria-controls', `${tabId}-panel`);
        tabItem.setAttribute('aria-selected', false);
        tabItem.setAttribute('aria-current', false);
        tabItem.setAttribute('tabindex', -1);

        tabPanel.setAttribute('id', `${tabId}-panel`);
        tabPanel.setAttribute('role', 'tabpanel');
        tabPanel.setAttribute('aria-labelledby', tabId);
        tabPanel.setAttribute('aria-hidden', true);

        // tab panel 제목 넣기
        let tabTitle = document.createElement('h1');
        tabTitle.setAttribute('class', 'sr-only');
        tabTitle.innerHTML = `${tabLabel}의 내용입니다.`;
        tabPanel.prepend(tabTitle);

        // 최초 설정
        if (tabItem == tabItems[0]) {
          tabItems[0].setAttribute('aria-selected', true);
          tabItems[0].setAttribute('tabindex', 0);
          tabItems[0].setAttribute('aria-current', true);
          tabPanels[0].setAttribute('aria-hidden', false);
        }

        // tab click
        tabItem.addEventListener('click', () => {
          let thisId = tabItem.getAttribute('id');
          let thisPanel = document.querySelector(`#${thisId}-panel`);

          init();

          tabItem.setAttribute('aria-selected', true);
          tabItem.setAttribute('aria-current', true);
          tabItem.setAttribute('tabindex', 0);
          thisPanel.setAttribute('aria-hidden', false);
        });
      });

      // tab contents의 keyboard move
      tabWrap.addEventListener('keydown', tabKeyboardMove);
    });
  },
  accordions: {
    init: () => {
      let accoWraps = document.querySelectorAll('.accordion');

      if (accoWraps.length < 1) return false;

      accoWraps.forEach((accoWrap) => {
        let isToggle = accoWrap.classList.contains('toggle');
        let accoTriggers = accoWrap.querySelectorAll('.acco-trigger');
        let accoPanels = accoWrap.querySelectorAll('.acco-panel');
        let accoItems = [];
        let childItems = accoWrap.children;

        // accordion items 추출/저장 - accordion 내 accordion이 있을 경우 때문
        for (var i = 0; i < childItems.length; i++) {
          accoItems.push(childItems[i]);
        }

        accoItems.forEach((accoItem) => {
          let accoHeader = accoItem.querySelector('.acco-header');
          let trigger = accoHeader.querySelector('.acco-trigger');
          let triggerId = trigger.getAttribute('id');
          let panel = accoItem.querySelector('.acco-panel');

          // init
          accoHeader.setAttribute('role', 'heading');
          trigger.setAttribute('aria-controls', `${triggerId}-panel`);
          trigger.setAttribute('aria-expended', false);
          trigger.setAttribute('title', '열기');

          panel.setAttribute('id', `${triggerId}-panel`);
          panel.setAttribute('aria-labelledby', triggerId);
          panel.setAttribute('aria-hidden', true);

          // click trigger
          trigger.addEventListener('click', () => {
            // toggle 여부
            if (isToggle) {
              accoItems.forEach((item, index) => {
                // 자신을 제외한 모두
                if (accoItem !== item) {
                  item.classList.remove('open');
                  accoTriggers[index].setAttribute('aria-expended', false);
                  accoTriggers[index].setAttribute('title', '열기');
                  accoPanels[index].setAttribute('aria-hidden', true);
                }
              });
            }

            if (!accoItem.classList.contains('open')) {
              // open
              accoItem.classList.add('open');
              trigger.setAttribute('aria-expended', true);
              trigger.setAttribute('title', '닫기');
              panel.setAttribute('aria-hidden', false);
            } else {
              // close
              accoItem.classList.remove('open');
              trigger.setAttribute('aria-expended', false);
              trigger.setAttribute('title', '열열기');
              panel.setAttribute('aria-hidden', true);
            }

            // accordion item 내부에 accordion이 있을 경우, 내부 accordion item 모두 close
            let innerAccos = panel.querySelectorAll('.accordion');
            if (innerAccos.length > 0) {
              innerAccos.forEach((innerAcco) => {
                let accoId = innerAcco.getAttribute('id');
                _ui.accordions.closeAll(accoId);
              });
            }
          });
        });
      });
    },
    isOpened: (_opt) => {
      let id = _opt.id;
      let oItemIdx = _opt.openedIndex;
      let acco = document.querySelector(`#${id}`);
      let accoItems = acco.querySelectorAll('.acco-item');

      accoItems.forEach((accoItem, index) => {
        let trigger = accoItem.querySelector('.acco-trigger');
        let accoPanel = accoItem.querySelector('.acco-panel');

        // open item
        const openedItem = () => {
          accoItem.classList.add('open');
          trigger.setAttribute('aria-expended', true);
          trigger.setAttribute('title', '닫기');
          accoPanel.setAttribute('aria-hidden', false);
        };

        // close item
        const closedItem = () => {
          accoItem.classList.remove('open');
          trigger.setAttribute('aria-expended', false);
          trigger.setAttribute('title', '열기');
          accoPanel.setAttribute('aria-hidden', true);
        };

        if (oItemIdx == 'all') {
          openedItem();
        } else if (oItemIdx.length > 0) {
          oItemIdx.forEach((idx) => {
            if (idx == index) {
              openedItem();
            }
          });
        } else {
          closedItem();
        }
      });
    },
    closeAll: (_id) => {
      let accoWrap = document.querySelector(`#${_id}`);
      let accoItems = accoWrap.querySelectorAll('.acco-item');
      let accoTriggers = accoWrap.querySelectorAll('.acco-trigger');
      let accoPanels = accoWrap.querySelectorAll('.acco-panel');

      accoItems.forEach((accoItem) => {
        accoItem.classList.remove('open');
      });

      accoTriggers.forEach((trigger) => {
        trigger.setAttribute('aria-expended', false);
        trigger.setAttribute('title', '열기');
      });

      accoPanels.forEach((panel) => {
        panel.setAttribute('aria-hidden', true);
      });
    },
  },
  tooltip: (_opt, _target) => {
    let isModal = _target.closest('.modal-wrap') ? true : false;
    let parent = isModal ? (_target.closest('.modal-body') ? _target.closest('.modal-body') : _target.closest('.modal-wrap')) : document.querySelector('.main-container');
    let id = _target.getAttribute('id');
    let title = _opt.title ? _opt.title : '';
    let cont = _opt.cont;
    let isTip = document.querySelector(`#${id}-tooltip`) ? true : false;
    let tipLayout = document.createElement('div');
    let tipObj = '';

    // 중복 방지
    if (isTip) return false;

    // tooltip 생성
    tipLayout.setAttribute('id', `${id}-tooltip`);
    tipLayout.setAttribute('role', 'tooltip');
    tipLayout.setAttribute('class', 'tooltip-layout');
    tipLayout.setAttribute('tabindex', -1);

    tipObj += '<span class="tip-arrow"></span>';
    tipObj += `<div class="tooltip-inner" tabindex="0">`;

    if (!!title) {
      tipObj += `
        <div class="tooltip-header">
          <h1 class="tooltip-title">${title}</h1>
        </div>
      `;
    }

    tipObj += `
        <div class="tooltip-body">${cont}</div>
      </div>
      <button type="button" class="tooltip-close">
        <span class="sr-only">도움말 닫기</span>
      </button>
    `;

    tipLayout.innerHTML = tipObj;
    parent.append(tipLayout);

    // set position
    let scrH = !isModal ? window.scrollY : parent.scrollTop;
    let tipArrow = tipLayout.querySelector('.tip-arrow');
    let tipArrowW = tipArrow.getBoundingClientRect().width;
    let tipArrowH = tipArrow.getBoundingClientRect().height;
    let parentT = parent.getBoundingClientRect().top;
    let parentL = parent.getBoundingClientRect().left;
    let parentW = parent.getBoundingClientRect().width;
    let parentH = !isModal ? window.innerHeight : _target.closest('.modal-wrap').getBoundingClientRect().height;
    let paPadL = parseFloat(window.getComputedStyle(parent).paddingLeft) - tipArrowW / 2;
    let triggerT = _target.getBoundingClientRect().top;
    let triggerL = _target.getBoundingClientRect().left - parentL;
    let triggerW = _target.getBoundingClientRect().width;
    let triggerH = _target.getBoundingClientRect().height;
    let tipW = tipLayout.getBoundingClientRect().width;
    let tipH = tipLayout.getBoundingClientRect().height;
    let tipT, tipL, arrowPos;

    // top
    if (parentH > triggerT + triggerH + tipH) {
      tipT = triggerT + triggerH - parentT + tipArrowH;
    } else {
      tipT = triggerT - tipH - parentT - tipArrowH;
      tipLayout.classList.add('top');
    }

    tipT = !isModal ? tipT : tipT + scrH;

    // tooltip left / arrow left
    if (parentW > triggerL + tipW) {
      tipL = triggerL - triggerW / 2 < paPadL ? paPadL : triggerL - triggerW / 2;
      arrowPos = triggerL - triggerW / 2 < paPadL ? triggerW / 2 : triggerW / 2 + (triggerW - tipArrowW) / 2;
    } else {
      tipL = triggerL + triggerW - tipW + triggerW / 2 < paPadL ? paPadL : triggerL + triggerW - tipW + triggerW / 2;
      arrowPos = triggerL + triggerW - tipW + triggerW / 2 < paPadL ? triggerL - paPadL + (triggerW - tipArrowW) / 2 : triggerL - tipL + (triggerW - tipArrowW) / 2;
    }

    tipArrow.style.left = `${arrowPos / 10}rem`;
    tipLayout.style.left = `${tipL / 10}rem`;
    tipLayout.style.top = `${tipT / 10}rem`;

    // tooltip focus
    tipLayout.focus();
    modalFocusTrap(`${id}-tooltip`);

    // tip close
    let closeBtn = tipLayout.querySelector('.tooltip-close');
    const tipClose = () => {
      tipLayout.classList.add('hide');

      tipLayout.addEventListener('animationend', () => {
        tipLayout.remove();
      });

      _target.focus();

      closeBtn.removeEventListener('click', tipClose);
      document.removeEventListener('click', extraClick);
    };

    // 영역 외 click시 닫기
    const extraClick = (e) => {
      let target = e.target;

      if (!tipLayout.contains(target) && !_target.contains(e.target)) {
        tipClose();
      }
    };

    // tooltip close button click
    closeBtn.addEventListener('click', tipClose);

    // 영역 외 click
    document.addEventListener('click', extraClick);

    // esc key
    tipLayout.addEventListener('keydown', (e) => {
      if (e.key == 'Escape') {
        e.preventDefault();
        tipClose();
      }
    });
  },
};

// page 이동
const movePage = (_path) => {
  location.href = _path + '.html';
};

// modal 내 focus trap
const modalFocusTrap = (_id) => {
  let modalWrap = document.querySelector(`#${_id}`);
  let focusEls = modalWrap.querySelectorAll('[href], button, input, textarea, select, [tabindex]:not([tabindex = "-1"])');
  let firstEl = focusEls[0];
  let lastEl = focusEls[focusEls.length - 1];

  // modal 내 focus 이동
  const moveFocus = (e) => {
    let focusEl = document.activeElement;

    if (e.key == 'Tab') {
      if (e.shiftKey && (focusEl == firstEl || focusEl == modalWrap)) {
        e.preventDefault();
        lastEl.focus();
      } else if (!e.shiftKey && focusEl == lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    }
  };

  modalWrap.addEventListener('keydown', moveFocus);
};

// tab contents keyboard
const tabKeyboardMove = (e) => {
  let tabLists = document.querySelectorAll('.tab-list');

  if (tabLists.length < 1) return false;

  tabLists.forEach((tabList) => {
    let tabs = tabList.querySelectorAll('.tab-item');
    let firstTab = tabs[0];
    let lastTab = tabs[tabs.length - 1];
    let nowFocus = e.target;

    switch (e.key) {
      case 'ArrowRight':
        if (nowFocus !== lastTab) {
          let nextTab = nowFocus.closest('li').nextElementSibling.querySelector('.tab-item');
          nextTab.focus();
        }
        break;
      case 'ArrowLeft':
        if (nowFocus !== firstTab) {
          let prevTab = nowFocus.closest('li').previousElementSibling.querySelector('.tab-item');
          prevTab.focus();
        }
        break;
      case 'Home':
        e.preventDefault();
        firstTab.focus();
        break;
      case 'End':
        e.preventDefault();
        lastTab.focus();
        break;
    }
  });
};
