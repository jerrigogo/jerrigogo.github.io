window.onload = () => {
  _ui.init();
  startVisual();
  // readyVod();
};

// init
let timer1, timer2, timer3, timer4, timer5, timer6;
const startVisual = () => {
  let scene1 = document.querySelector('.scene1');
  let scene2 = document.querySelector('.scene2');
  let scene3 = document.querySelector('.scene3');
  let visual = document.querySelector('.visual');

  scene1.classList.add('act');

  timer2 = setTimeout(() => {
    scene1.classList.add('end');
    clearTimeout(timer2);
  }, 1800);

  timer3 = setTimeout(() => {
    scene2.classList.add('act');
    clearTimeout(timer3);
  }, 2500);

  timer4 = setTimeout(() => {
    scene2.classList.add('end');
    clearTimeout(timer4);
  }, 5000);

  timer5 = setTimeout(() => {
    scene3.classList.add('act');
    clearTimeout(timer5);
  }, 5500);

  timer6 = setTimeout(() => {
    scene3.classList.add('end');
    visual.classList.add('terminate');
    setScrollbar();

    clearTimeout(timer6);
  }, 9500);
};

// skip intro
const skipIntro = () => {
  let visual = document.querySelector('.visual');

  visual.classList.add('terminate');

  setScrollbar();

  // 각 scene의 timer 모두 종료
  clearTimeout(timer1);
  clearTimeout(timer2);
  clearTimeout(timer3);
  clearTimeout(timer4);
  clearTimeout(timer5);
  clearTimeout(timer6);
};

// set scrollbar
const setScrollbar = () => {
  let timer = setTimeout(() => {
    gsap.registerPlugin(ScrollTrigger);

    let mainContainer = document.querySelector('#MainContainer');
    let bodyScrollBar = Scrollbar.init(mainContainer, {
      damping: 0.1,
    });

    ScrollTrigger.scrollerProxy(mainContainer, {
      scrollTop(value) {
        if (arguments.length) {
          bodyScrollBar.scrollTop = value;
        }

        return bodyScrollBar.scrollTop;
      },
    });

    bodyScrollBar.addListener(ScrollTrigger.update);

    clearTimeout(timer);

    // 홍보동영상 팝업 open
    let vodBtn = document.querySelector('.show-vod');
    vodBtn.click();
  }, 500);

  // // 홍보동영상 팝업 open
  // let vodBtn = document.querySelector('.show-vod');
  // vodBtn.click();
};

// 홍보동영상 ready
// let player;
// const readyVod = () => {
//   player = new YT.Player('VodPlayer', {
//     videoId: 'fkcHMhy9Vlk',
//     width: '100%',
//     height: '100%',
//   });
// };

const playVideo = () => {
  let vodBrochure = document.querySelector('#VodBrochure');
  let vodFuture = document.querySelector('#FutureVod');
  // player.playVideo();

  vodBrochure.currentTime = 0;
  vodBrochure.play();
  vodFuture.pause();
};

const stopVideo = () => {
  let vodBrochure = document.querySelector('#VodBrochure');
  let vodFuture = document.querySelector('#FutureVod');
  // player.stopVideo();

  vodBrochure.pause();
  vodFuture.play();
};

// 홍보동영상 팝업 open
let isOpened = false;
const vodModal = (_state) => {
  switch (_state) {
    case 'open':
      _ui.modal.open('PopMainVod');
      playVideo();
      break;
    case 'close':
      _ui.modal.close('PopMainVod');
      stopVideo();

      // header
      setHeaderAni();
      // main ani
      if (!isOpened) {
        setMainAni();
        isOpened = true;
      }

      break;
  }
};

// header
const setHeaderAni = () => {
  let header = document.querySelector('#HeaderContainer');

  header.classList.add('show');

  gsap.registerPlugin(ScrollTrigger);

  const headerAni = gsap
    .from(header, {
      yPercent: -100,
      paused: true,
      duration: 0.2,
      ease: 'power1.inOut',
    })
    .progress(1);

  ScrollTrigger.create({
    scroller: '.main-container',
    start: 'top top',
    end: 'max',
    onUpdate: (self) => {
      self.direction === -1 ? headerAni.play() : headerAni.reverse();
    },
  });
};

// future section animation
const setMainAni = () => {
  let scriptCont = document.querySelector('#FutureConts');
  let mainScript = scriptCont.querySelector('.section-title');
  let subScript = scriptCont.querySelector('.info-text');
  let logoEgi = scriptCont.querySelector('.logo-egi');
  let vodBtn = scriptCont.querySelector('.show-vod');
  let scrDwn = document.querySelector('#ScrollDown');
  let futureVod = document.querySelector('#FutureVod');

  gsap.registerPlugin(ScrollTrigger);

  /** future section **/
  // background image animation
  gsap.fromTo(
    '#Future',
    {
      clipPath: 'circle(0% at 50% 50%)',
    },
    {
      clipPath: 'circle(100% at 50% 50%)',
      duration: 1,
      delay: 0.3,
      ease: 'power2.inOut',
    }
  );

  // text animation
  let futureTl = gsap.timeline();
  futureTl
    .to('#FutureConts', { opacity: 1, duration: 0.5, ease: 'power1.out' }, 1)
    .to(mainScript, { y: 0, duration: 0.5, ease: 'power1.out' }, 1.2)
    .to(subScript, { y: 0, duration: 0.5, ease: 'power1.out' }, 1.5)
    .to(logoEgi, { y: 0, duration: 0.5, ease: 'power1.out' }, 1.8);

  // .ani-section.future fixed
  gsap.to('.ani-section.future', {
    scrollTrigger: {
      trigger: '.ani-section.future',
      scroller: '.main-container',
      start: 'top top',
      end: `bottom -${window.innerHeight}`,
      pin: true,
      scrub: 3,
      ease: 'none',
      onEnter: () => {
        futureVod.play();
      },
      onLeave: () => {
        futureVod.pause();
      },
      onEnterBack: () => {
        futureVod.play();
      },
    },
  });

  gsap.to(vodBtn, {
    scrollTrigger: {
      trigger: '.ani-section.future',
      scroller: '.main-container',
      start: 'top 0.1%',
      end: 'bottom 50%',
      scrub: 3,
      ease: 'power2.out',
    },
    opacity: 0,
    y: 140,
  });

  gsap.to(scrDwn, {
    scrollTrigger: {
      trigger: '.ani-section.future',
      scroller: '.main-container',
      start: 'top 0.1%',
      end: 'bottom 50%',
      scrub: 3,
      ease: 'power2.out',
    },
    opacity: 0,
    y: 140,
  });

  gsap.to(logoEgi, {
    scrollTrigger: {
      trigger: '.ani-section.future',
      scroller: '.main-container',
      start: 'top 0.1%',
      end: 'bottom 50%',
      scrub: 3,
      ease: 'power2.out',
    },
    opacity: 0,
  });

  gsap.to('#FutureConts', {
    scrollTrigger: {
      trigger: '.ani-section.future',
      scroller: '.main-container',
      start: 'top 0.1%',
      end: 'bottom 50%',
      scrub: 3,
      ease: 'power2.out',
    },
    y: -140,
  });

  gsap.to('.counter-cont', {
    scrollTrigger: {
      trigger: '.ani-section.future',
      scroller: '.main-container',
      start: `top 0.1%`,
      end: 'bottom 30%',
      scrub: 2,
      ease: 'power2.out',
    },
    y: 0,
    duration: 1,
    opacity: 1,
    stagger: 1,
  });

  /** 전문금융파트너 section **/
  // fixed section
  let slides = gsap.utils.toArray('.ani-section.partner .slide-item');
  gsap.to('.ani-section.partner', {
    scrollTrigger: {
      trigger: '.ani-section.partner',
      scroller: '.main-container',
      start: 'top 0.1%',
      // end: `bottom -${window.innerHeight * 2}`,
      end: '+=9600',
      pin: true,
      scrub: true,
      ease: 'none',
    },
  });

  let partnerTl = gsap.timeline({
    scrollTrigger: {
      trigger: '.ani-section.partner',
      scroller: '.main-container',
      start: 'top 0.1%',
      // end: `bottom -${window.innerHeight}`,
      scrub: 2,
      ease: 'power2.out',
    },
  });

  let partnerText = gsap.utils.toArray('.partner-conts .text');
  partnerText.forEach((text, i) => {
    partnerTl.to(text, { y: 0, opacity: 1, duration: 0.5 }, i * 0.2).addLabel(`textcont${i}`);
  });

  partnerTl.to('.partner-conts', { y: 0, opacity: 0, duration: 1 }, 'textcont2+=2');
  partnerTl.to('.ani-section.partner .slide-wrap', { opacity: 1, duration: 1 }, 'textcont2+=2');
  partnerTl.to(
    slides,
    {
      scrollTrigger: {
        trigger: '.ani-section.partner .slide-wrap',
        scroller: '.main-container',
        start: 'center center',
        end: '+=9600',
        scrub: 1,
        snap: 1 / (slides.length - 1),
      },
      xPercent: -100 * (slides.length - 1),
      duration: 1,
      ease: 'none',
    },
    'textcont2+=3'
  );

  // growup
  gsap.to('.ani-section.growup', {
    scrollTrigger: {
      trigger: '.ani-section.growup',
      scroller: '.main-container',
      start: 'top top',
      end: `bottom -${window.innerHeight * 3}`,
      pin: true,
      scrub: 2,
      ease: 'none',
    },
  });

  gsap.to('.growup-vod-wrap', {
    scrollTrigger: {
      trigger: '.ani-section.growup',
      scroller: '.main-container',
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1,
    },
    x: 0,
    y: 0,
    width: '100%',
    height: '100%',
    duration: 2,
    ease: 'none',
  });

  gsap.to('.growup-txt-wrap', {
    scrollTrigger: {
      trigger: '.ani-section.growup',
      scroller: '.main-container',
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1,
    },
    opacity: 1,
    duration: 2,
    ease: 'none',
  });

  // let growupslide = gsap.utils.toArray('.growup-vod-wrap .growup-slide');
  // growupslide
};
